function [ dy ] = sdof( t,y )
%SDOF Summary of this function goes here
%   Detailed explanation goes here
dy=zeros(2,1);
global uel tel m c k;
uy=interp1(tel,uel,t);

dy(1)=y(2);
dy(2)=(-m*uy-k*y(1)-c*y(2))/m;

end

