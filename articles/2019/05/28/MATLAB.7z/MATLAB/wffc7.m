function [ dy ] = wffc7(t,y )
%WFFC7 Summary of this function goes here
%   Detailed explanation goes here
dy=zeros(14,1);
global g u r m k c uel tel;
uy=interp1(tel,uel,t);

d1=y(1);
dd1=y(2);
d2=y(3);
dd2=y(4);
d3=y(5);
dd3=y(6);
d4=y(7);
dd4=y(8);
d5=y(9);
dd5=y(10);
d6=y(11);
dd6=y(12);
d7=y(13);
dd7=y(14);
A1=1+6*(u*sign(dd1)*cos(d1)+sin(d1))*sin(d1);
A2=u*sign(dd1)+6*(sign(dd1)*cos(d1)+sin(d1))*cos(d1);
A3=(g/r)*7*(u*sign(dd1)*cos(d1)+sin(d1));

dy(1)=dd1;
dy(2)=uy*(u*sign(dd1)*sin(d1)-cos(d1))/r/A1+(k*(r*sin(d1)-d2)+c*(r*dd1*cos(d1)-dd2))*(u*sign(dd1)*sin(d1)-cos(d1))/m/r/A1-A3/A1-A2/A1*dd1^2;

dy(3)=dd2;
dy(4)=(-m*uy-c*(dd2-dd3)-c*(dd2-dd1)-k*(d2-d3)-k*(d2-d1))/m;

dy(5)=dd3;
dy(6)=(-m*uy-c*(dd3-dd4)-c*(dd3-dd2)-k*(d3-d4)-k*(d3-d2))/m;

dy(7)=dd4;
dy(8)=(-m*uy-c*(dd4-dd5)-c*(dd4-dd3)-k*(d4-d5)-k*(d4-d3))/m;

dy(9)=dd5;
dy(10)=(-m*uy-c*(dd5-dd6)-c*(dd5-dd4)-k*(d5-d6)-k*(d5-d4))/m;

dy(11)=dd6;
dy(12)=(-m*uy-c*(dd6-dd7)-c*(dd6-dd5)-k*(d6-d7)-k*(d6-d5))/m;

dy(13)=dd7;
dy(14)=(-m*uy-c*(dd7-dd6)-k*(d7-d6))/m;
% disp(t) 
% disp(dy(2))
if rem(t,0.02)<=0.00001
    disp(t)
end



end

