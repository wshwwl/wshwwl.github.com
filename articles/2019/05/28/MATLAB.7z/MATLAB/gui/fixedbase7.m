function [ dy ] = fixedbase7( t,y )
%FASTWFFC7 �̶��ػ�ϵͳ��΢�ַ���
%   Detailed explanation goes here
dy=zeros(14,1);
global m k c ag tg;
ay=interp1(tg,ag,t);

dy(1)=y(2);
dy(2)=0;

dy(3)=y(4);
dy(4)=(-m*ay-c*(y(4)-y(6))-c*(y(4)-y(2))-k*(y(3)-y(5))-k*(y(3)-y(1)))/m;

dy(5)=y(6);
dy(6)=(-m*ay-c*(y(6)-y(8))-c*(y(6)-y(4))-k*(y(5)-y(7))-k*(y(5)-y(3)))/m;

dy(7)=y(8);
dy(8)=(-m*ay-c*(y(8)-y(10))-c*(y(8)-y(6))-k*(y(7)-y(9))-k*(y(7)-y(5)))/m;

dy(9)=y(10);
dy(10)=(-m*ay-c*(y(10)-y(12))-c*(y(10)-y(8))-k*(y(9)-y(11))-k*(y(9)-y(7)))/m;

dy(11)=y(12);
dy(12)=(-m*ay-c*(y(12)-y(14))-c*(y(12)-y(10))-k*(y(11)-y(13))-k*(y(11)-y(9)))/m;

dy(13)=y(14);
dy(14)=(-m*ay-c*(y(14)-y(12))-k*(y(13)-y(11)))/m;

end

