%%  FPS��ͼ
clear all;
global g u r w A;
g=9.8;
u=0.02;
r=0.5;
w=5;
A=2.75;

tt=0:0.01:100;
[t,y]=ode45(@wffc,tt,[0,0]);
d=y(:,1);
v=100*y(:,2);
figure(1)
plot(d,v,'black')

%% FPS�ͻ�����
Q=r*(u*sign(v).*(v.^2+g*cos(d)/r)+g*sin(d)/r)/g;
figure(2)
plot(d,Q,'black');

%% ת����r�ı仯
r=1;
ul=[0.05,0.1,0.15];
wl=2:5;
for i=1:3
    for j=1:4
        w=wl(j);
        u=ul(i);
        [t,y]=ode45(@wffc,tt,[0,0]);
        yl(i,j)=max(abs(y(:,1)));
    end
end
figure(3)
plot(wl,yl)
%% ת����w�ı仯
u=0.1;
rl=[0.5,1,2];
wl=2:5;
for i=1:3;
    for j=1:4
        i
        j
        w=wl(j);
        r=rl(i);        
        [t,y]=ode45(@wffc,tt,[0,0]);
        yl(i,j)=max(abs(y(:,1)));
    end
end
figure(4)
plot(wl,yl)