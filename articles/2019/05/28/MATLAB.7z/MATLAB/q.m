dt=0.0001;
t1=0:dt:0.011;
t2=0:dt:0.011*200;
t3=0:dt:1;
T=0.022;
as=sin(2*pi*t1/T);
as2=[as,zeros(1,length(t2)-length(t1))];
figure(1);
plot(t2,as2);

as3=[as,zeros(1,length(t3)-length(t1))];
as3=repmat(as3,1,100);
t3=0:dt:length(as3)*dt-dt;
figure(2);
plot(t3,as3);

