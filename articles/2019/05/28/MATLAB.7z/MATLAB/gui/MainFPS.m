function varargout = MainFPS(varargin)
% MAINFPS MATLAB code for MainFPS.fig
%      MAINFPS, by itself, creates a new MAINFPS or raises the existing
%      singleton*.
%
%      H = MAINFPS returns the handle to a new MAINFPS or the handle to
%      the existing singleton*.
%
%      MAINFPS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAINFPS.M with the given input arguments.
%
%      MAINFPS('Property','Value',...) creates a new MAINFPS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MainFPS_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MainFPS_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MainFPS

% Last Modified by GUIDE v2.5 23-Apr-2019 00:31:07

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MainFPS_OpeningFcn, ...
                   'gui_OutputFcn',  @MainFPS_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MainFPS is made visible.
function MainFPS_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MainFPS (see VARARGIN)

% Choose default command line output for MainFPS
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MainFPS wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = MainFPS_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton_addlayer.
function pushbutton_addlayer_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_addlayer (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    data=get(handles.uitable_louceng,'data');
    if isempty(data)
        new={0,0,0};
    else
        new=data(end,:);
    end
    data=[data;new];
    set(handles.uitable_louceng,'data',data);


% --- Executes on button press in pushbutton_deletelayer.
function pushbutton_deletelayer_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_deletelayer (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    data=get(handles.uitable_louceng,'data'); 
    if size(data,1)<3
        return;
    end
    indices=get(handles.uitable_louceng,'UserData');
    if isempty(indices)
        indices=size(data,1);
    end     
    data(indices(1),:)=[];
    set(handles.uitable_louceng,'data',data);


% --- Executes when selected cell(s) is changed in uitable_louceng.
function uitable_louceng_CellSelectionCallback(hObject, eventdata, handles)
% hObject    handle to uitable_louceng (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)
    set(hObject,'Userdata',eventdata.Indices);



function edit_inputwave_Callback(hObject, eventdata, handles)
% hObject    handle to edit_inputwave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_inputwave as text
%        str2double(get(hObject,'String')) returns contents of edit_inputwave as a double


% --- Executes during object creation, after setting all properties.
function edit_inputwave_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_inputwave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_sltinputwave.
function pushbutton_sltinputwave_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_sltinputwave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,pathname]=uigetfile({'*.txt','*.txt';'*.csv','*.csv'},'ѡ������ļ�');
if filename~=0
    set(handles.edit_inputwave,'string',[pathname,filename]);
end



% --- Executes on button press in pushbutton_importinputwave.
function pushbutton_importinputwave_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_importinputwave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
path=get(handles.edit_inputwave,'string');
skiplines=str2num(get(handles.edit_skiplines,'string'));
try
    [time,ag]=importfile(path,skiplines);
    if any(isnan(ag))||any(isnan(time))
        throw();
    end
    len=length(time);
    dt=(time(len)-time(1))/(len-1);
    maxag=max(abs(ag));
    axes(handles.axes_inputwave);
    plot(time,ag);
    legend(['ʱ������',num2str(dt),';����ֵ��',num2str(maxag)]);
    set(handles.axes_inputwave,'Userdata',{dt,ag});
catch
    uiwait(msgbox('����ʧ�ܣ�','modal'));
end
    


function edit_skiplines_Callback(hObject, eventdata, handles)
% hObject    handle to edit_skiplines (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_skiplines as text
%        str2double(get(hObject,'String')) returns contents of edit_skiplines as a double


% --- Executes during object creation, after setting all properties.
function edit_skiplines_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_skiplines (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_r_Callback(hObject, eventdata, handles)
% hObject    handle to edit_r (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_r as text
%        str2double(get(hObject,'String')) returns contents of edit_r as a double


% --- Executes during object creation, after setting all properties.
function edit_r_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_r (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_u_Callback(hObject, eventdata, handles)
% hObject    handle to edit_u (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_u as text
%        str2double(get(hObject,'String')) returns contents of edit_u as a double


% --- Executes during object creation, after setting all properties.
function edit_u_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_u (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_solve.
function pushbutton_solve_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_solve (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


set(hObject,'string','�����...');
set(hObject,'BackgroundColor','red');
pause(0.1);
try
    floordata=get(handles.uitable_louceng,'data');
    ag=get(handles.axes_inputwave,'Userdata');
    dt=ag{1};
    ag=ag{2};
    r=get(handles.edit_r,'string');
    r=str2double(r);
    u=get(handles.edit_u,'string');
    u=str2double(u);
    [tfps,dfps,vfps,afps,rdfps]=solve_fps(floordata,r,u,dt,ag);
    [tfix,dfix,vfix,afix,rdfix]=solve_fixedbase(floordata,dt,ag);
catch
    uiwait(msgbox('���ʧ�ܣ��������ݣ�','modal'));
    set(hObject,'string','���');
    set(hObject,'BackgroundColor',[0,0.5,0]);
    return
end
[afps_max,index_fps]=max(abs(afps),[],1);
[afix_max,index_fix]=max(abs(afix),[],1);
set(handles.uitable_rfps,'data',[afps_max;max(abs(vfps),[],1);max(abs(dfps),[],1);max(abs(rdfps),[],1);tfps(index_fps)']');
set(handles.uitable_rfixed,'data',[afix_max;max(abs(vfix),[],1);max(abs(dfix),[],1);max(abs(rdfix),[],1);tfix(index_fix)']');

set(hObject,'BackgroundColor',[0,0.5,0]);
set(hObject,'string','���');
set(hObject,'Userdata',{tfps,dfps,vfps,afps,rdfps;tfix,dfix,vfix,afix,rdfix});

str_louceng='��1��';
for i=2:size(floordata,1)
    str_louceng=[str_louceng,'|��',num2str(i),'��'];
end
set(handles.popupmenu_louceng,'string',str_louceng);



% --- Executes on selection change in popupmenu_louceng.
function popupmenu_louceng_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_louceng (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_louceng contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_louceng


% --- Executes during object creation, after setting all properties.
function popupmenu_louceng_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_louceng (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton_jiasudu.
function radiobutton_jiasudu_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_jiasudu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_jiasudu


% --- Executes on button press in radiobutton_sudu.
function radiobutton_sudu_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_sudu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_sudu


% --- Executes on button press in radiobutton_weiyi.
function radiobutton_weiyi_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_weiyi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_weiyi


% --- Executes on button press in checkbox_fixedbase.
function checkbox_fixedbase_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_fixedbase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_fixedbase


% --- Executes on button press in pushbutton_saverst.
function pushbutton_saverst_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_saverst (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
[filename,filepath]=uiputfile({'*.csv','*.csv'});
fullpath=[filepath,filename];
data=get(handles.pushbutton_solve,'Userdata');
floordata=get(handles.uitable_louceng,'data');
nfloor=size(floordata,1);
temp=[data{1,1},data{1,2},data{1,3},data{1,4},data{1,5},data{2,1},data{2,2},data{2,3},data{2,4},data{2,5}];

fid=fopen(fullpath,'wt');
fprintf(fid,'time_FPS');
for i=1:nfloor
    fprintf(fid,[',FPS��',num2str(i),'��λ��']);
end
for i=1:nfloor
    fprintf(fid,[',FPS��',num2str(i),'���ٶ�']);
end
for i=1:nfloor
    fprintf(fid,[',FPS��',num2str(i),'����ٶ�']);
end
for i=1:nfloor
    fprintf(fid,[',FPS��',num2str(i),'����λ��']);
end
fprintf(fid,',time_FixedBase');
for i=1:nfloor
    fprintf(fid,[',�̶����׵�',num2str(i),'��λ��']);
end
for i=1:nfloor
    fprintf(fid,[',�̶����׵�',num2str(i),'���ٶ�']);
end
for i=1:nfloor
    fprintf(fid,[',�̶����׵�',num2str(i),'����ٶ�']);
end
for i=1:nfloor
    fprintf(fid,[',�̶����׵�',num2str(i),'����λ��']);
end
fprintf(fid,'\n');
C={'%f,','\n'};
fprintf(fid,[C{[ones(1,8*nfloor+2),2]}],temp');
catch
    fclose all
    uiwait(msgbox('����ʧ�ܣ��������ݣ�','modal'));
    return
end
fclose all;
uiwait(msgbox('������ɣ�','modal'));






% --- Executes on button press in pushbutton_plot.
function pushbutton_plot_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
louceng=get(handles.popupmenu_louceng,'value');
rstn=get(handles.popupmenu_rst,'value');
isfixed=get(handles.checkbox_fixedbase,'value');
data=get(handles.pushbutton_solve,'Userdata');
if isempty(data)
    return
end
axes(handles.axes2);

tfps=data{1,1};
rfps=data{1,rstn+1};
rfps=rfps(:,louceng);
hold off;
h1=plot(tfps,rfps);
legend('FPS������Ӧ');
if isfixed
    tfix=data{2,1};
    fix=data{2,rstn+1};
    fix=fix(:,louceng);
    hold on ;
    h2=plot(tfix,fix,'r');
    set(gca,'child',[h1 h2]);
    legend('�̶�������Ӧ','FPS������Ӧ');
end


% --- Executes on selection change in popupmenu_rst.
function popupmenu_rst_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_rst (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_rst contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_rst


% --- Executes during object creation, after setting all properties.
function popupmenu_rst_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_rst (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
