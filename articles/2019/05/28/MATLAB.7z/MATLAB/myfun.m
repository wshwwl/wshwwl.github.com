function F = myfun( x )
%FYFUN Summary of this function goes here
%   Detailed explanation goes here
da=13685;
r=1044;
l1=r*sin(x./2);
l2=sqrt(r^2-l1.^2);
a1=x.*r.^2/2;
a2=l1.*l2;


F=a1-a2-da;

end

