%%  
clear all;
global uel tel m k c;
m=1;
k=1;
c=0.1;
load('uel.mat')
uel=uel*9.8;
tel=0:0.02:0.02*length(uel)-0.02;
init=zeros(2,1);
ddy=zeros(length(tel),1);
[t,y]=ode45(@sdof,tel,init);
for i=1:length(t)
    dy=sdof(t(i),y(i,:));
    ddy(i)=dy(2);
end
% ddy=ddy+uel;
plot(t,y(:,1))

%%
wn=sqrt(k/m);
f=wn/2/pi;
h=c/2/m/wn;

[acc,vel,dis]=sdof_response(h,f,0.02,uel);
hold on;
plot(tel,dis,'r');