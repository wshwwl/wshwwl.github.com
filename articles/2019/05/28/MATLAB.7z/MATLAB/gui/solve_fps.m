function [ rt,rd,rv,ra,rrd] = solve_fps(floordata,r,u,dt,ag)
% function [ rt,ry,ra] = solve_fps(floordata,r,u,dt,ag)
%SOLVE_FPS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
nfloor=size(floordata,1);
ag=ag*9.8;
tg=0:dt:dt*length(ag)-dt;
m=floordata(:,1);
m=cell2mat(m);
k=floordata(2:end,2);
k=cell2mat(k);
k=[1;k];
k=k*1000;
c=floordata(:,3);
c=cell2mat(c);
c=[1;c];

m1=m(1);
M=sum(m(2:end));

init=zeros(nfloor*2,1);
[rt,ry]=ode45(@wffc_fps,tg,init);

rd=ry(:,1:2:2*nfloor);
rv=ry(:,2:2:2*nfloor);

%���ݼ���õ���λ�ơ��ٶȣ�������Լ��ٶ���Ӧ
ra=zeros(length(rt),nfloor);
for tn=1:length(rt)
    dy=wffc_fps(rt(tn),ry(tn,:));
    ra(tn,:)=dy(2:2:2*nfloor);
end

ra(:,1)=r*cos(rd(:,1)).*ra(:,1)-r*sin(rd(:,1)).*rv(:,1).^2;
rv(:,1)=r*cos(rd(:,1)).*rv(:,1);
rd(:,1)=r*sin(rd(:,1));


% %��Լ��ٶȼ��ϵ�����ٶȣ��õ����Լ��ٶ�
for i=1:nfloor
    ra(:,i)=ra(:,i)+ag;
end

rrd=rd(:,2:end)-rd(:,1:end-1);
rrd=[rd(:,1),rrd];

    function dy=wffc_fps(t,y)
        % n ���ɶ�ϵͳ΢�ַ�����
        dy=zeros(nfloor*2,1);
        g=9.8;
        uy=interp1(tg,ag,t,'linear'); %�������Բ�ֵ����ȡ��Ӧʱ��ĵ�����ٶ�ֵ

        % �м����
        sgn=sign(y(2));
        siny=sin(y(1));
        cosy=cos(y(1));
        A1=1+(M/m1)*(u*sgn*cosy+siny)*siny;
        A2=u*sgn+(M/m1)*(u*sgn*cosy+siny)*cosy;
        A3=(g/r)*((M+m1)/m1)*(u*sgn*cosy+siny);

        %΢�ַ�����
        dy(1)=y(2);
        dy(2)=uy*(u*sgn*siny-cosy)/r/A1+(k(2)*(r*siny-y(3))+c(2)*(r*y(2)*cosy-y(4)))*(u*sgn*siny-cosy)/m1/r/A1-A3/A1-A2/A1*y(2)^2;

        G=(m1+M)*g+r*M*(cosy*y(2)^2+siny*dy(2));
        P=-G*siny-(k(2)*(r*siny-y(3))+c(2)*(r*y(2)*cosy-y(4)))*cosy-m1*uy*cosy;
        N=G*cosy-(m1*uy+k(2)*(r*siny-y(3))+c(2)*(r*y(2)*cosy-y(4)))*siny+m1*r*y(2)^2;
        F=u*N;
        if abs(y(2))<1e-5&&abs(P)<=abs(F)
            dy(1)=0;
            dy(2)=0;
        end
        
        if nfloor==2
            dy(3)=y(4);
            dy(4)=(-m(2)*uy-c(2)*(y(4)-r*y(2)*cosy)-k(2)*(y(3)-r*siny))/m(2);
        end
        if nfloor>2
            dy(3)=y(4);
            dy(4)=(-m(2)*uy-c(3)*(y(4)-y(6))-c(2)*(y(4)-r*y(2)*cosy)-k(3)*(y(3)-y(5))-k(2)*(y(3)-r*siny))/m(2);
            
            for fn=3:nfloor
                dy(fn*2-1)=y(fn*2);
                if fn==nfloor
                    dy(fn*2)=(-m(fn)*uy-c(fn)*(y(2*fn)-y(2*fn-2))-k(fn)*(y(2*fn-1)-y(2*fn-3)))/m(fn);
                else
                    dy(fn*2)=(-m(fn)*uy-c(fn+1)*(y(2*fn)-y(2*fn+2))-c(fn)*(y(2*fn)-y(2*fn-2))-k(fn+1)*(y(2*fn-1)-y(2*fn+1))-k(fn)*(y(2*fn-1)-y(2*fn-3)))/m(fn);
                end
            end
        end 

    end


end

