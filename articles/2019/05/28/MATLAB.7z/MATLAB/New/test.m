function test
%TEST �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
load('uel.mat')
load('utaft.mat')
% ag=uel*9.8;
ag=utaft*9.8;
tg=0:0.02:0.02*length(ag)-0.02;
g=9.8;
u=0.12;
r=1;

m=345000;
k=3.4e8;
c=3e6;

tspan=0:0.02:30;
init=zeros(14,1);
last_acc=0;
fastwffc7(0,0)


function [ dy ] = fastwffc7( t,y )
% 7 ���ɶ�ϵͳ΢�ַ�����
%   Detailed explanation goes here
dy=zeros(14,1);
uy=interp1(tg,ag,t,'linear'); %�������Բ�ֵ����ȡ��Ӧʱ��ĵ�����ٶ�ֵ

% �м����
sgn=sign(y(2));
siny=sin(y(1));
cosy=cos(y(1));
A1=1+6*(u*sgn*cosy+siny)*siny;
A2=u*sgn+6*(u*sgn*cosy+siny)*cosy;
A3=(g/r)*7*(u*sgn*cosy+siny);


%΢�ַ�����
dy(1)=y(2);
dy(2)=uy*(u*sgn*siny-cosy)/r/A1+(k*(r*siny-y(3))+c*(r*y(2)*cosy-y(4)))*(u*sgn*siny-cosy)/m/r/A1-A3/A1-A2/A1*y(2)^2;

G=7*m*g+6*r*m*(cosy*y(2)^2+siny*dy(2));
P=-G*siny-(k*(r*siny-y(3))+c*(r*y(2)*cosy-y(4)))*cosy-m*uy*cosy;
N=G*cosy-(m*uy+k*(r*siny-y(3))+c*(r*y(2)*cosy-y(4)))*siny+m*r*y(2)^2;
F=u*N;
if abs(y(2))<1e-5&&abs(P)<=abs(F)
    dy(1)=0;
    dy(2)=0;
end

dy(3)=y(4);
dy(4)=(-m*uy-c*(y(4)-y(6))-c*(y(4)-r*y(2)*cosy)-k*(y(3)-y(5))-k*(y(3)-r*siny))/m;

dy(5)=y(6);
dy(6)=(-m*uy-c*(y(6)-y(8))-c*(y(6)-y(4))-k*(y(5)-y(7))-k*(y(5)-y(3)))/m;

dy(7)=y(8);
dy(8)=(-m*uy-c*(y(8)-y(10))-c*(y(8)-y(6))-k*(y(7)-y(9))-k*(y(7)-y(5)))/m;

dy(9)=y(10);
dy(10)=(-m*uy-c*(y(10)-y(12))-c*(y(10)-y(8))-k*(y(9)-y(11))-k*(y(9)-y(7)))/m;

dy(11)=y(12);
dy(12)=(-m*uy-c*(y(12)-y(14))-c*(y(12)-y(10))-k*(y(11)-y(13))-k*(y(11)-y(9)))/m;

dy(13)=y(14);
dy(14)=(-m*uy-c*(y(14)-y(12))-k*(y(13)-y(11)))/m;

end

end


